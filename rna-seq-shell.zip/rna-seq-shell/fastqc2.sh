#!/bin/bash
cd /Users/yujiokano/Desktop/glioma_RNAseq

mkdir -p fastqc
	 
PREFIX="" 
    
    for num in {14..21}
do
    ID="Sample_${num}h"
    echo "==== target: ${ID} ===="
    mkdir -p ./fastqc/${ID}
	
	fastqc -t 8 --nogroup ./fastq/${ID}_1.fastq.gz -o ./fastqc/${ID} \
		2>&1 | tee ./fastqc/${ID}/${ID}_1.log
		
	fastqc -t 8 --nogroup ./fastq/${ID}_2.fastq.gz -o ./fastqc/${ID} \
		2>&1 | tee ./fastqc/${ID}/${ID}_2.log
done

echo "==== DONE ==="