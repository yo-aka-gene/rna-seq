#!/bin/bash
cd /Users/yujiokano/Desktop/glioma_RNAseq


mkdir -p trimgalore

    for num in {14..21}
do
    ID="Sample_${num}h"
    echo "==== target: ${ID} ===="
	mkdir -p ./trimgalore/${ID}
	
	trim_galore -q 25 -j 4 --fastqc --fastqc_args "--nogroup --outdir ./trimgalore/${ID}"   \
	-o ./trimgalore/${ID} \
	--paired \
	./fastq/${ID}_1.fastq.gz \
	./fastq/${ID}_2.fastq.gz \
		2>&1 | tee ./trimgalore/${ID}/${ID}.log
done

echo "==== DONE ==="