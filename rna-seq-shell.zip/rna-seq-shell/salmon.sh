#!/bin/bash
source /Users/yujiokano/anaconda3/etc/profile.d/conda.sh
conda activate salmon

cd /Users/yujiokano/Desktop/glioma_RNAseq
mkdir -p Salmon

    ID="Sample_30h"
    echo "==== target: ${ID} ===="
    mkdir -p ./Salmon/${ID}

	salmon quant \
	-i /Users/yujiokano/Desktop/Salmon_index/hg38_index \
	-g /Users/yujiokano/Desktop/Salmon_index/gencode.v34.metadata.txt \
	-l A \
	-1 ./trimgalore/${ID}/${ID}_1_val_1.fq.gz \
	-2 ./trimgalore/${ID}/${ID}_2_val_2.fq.gz \
	-p 16 \
	-o ./Salmon/${ID}
done

echo "==== DONE ==="